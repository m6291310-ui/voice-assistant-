package com.example.voiceassistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Timers {
    private fun pi(c: Context, id: Int, label: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, id, Intent(c, TimerReceiver::class.java).putExtra("label", label),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // setAlarmClock يرن حتى لو الموبايل مقفول أو في وضع توفير الطاقة
    fun set(c: Context, sec: Long) {
        val id = (System.currentTimeMillis() / 1000 % 1000000).toInt() + 1
        val am = c.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + sec * 1000, show), pi(c, id, Parser.words(sec)))
        val sp = c.getSharedPreferences("va_t", Context.MODE_PRIVATE)
        val s = sp.getStringSet("ids", emptySet())!!.toMutableSet()
        s.add(id.toString())
        sp.edit().putStringSet("ids", s).apply()
    }

    fun cancelAll(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val sp = c.getSharedPreferences("va_t", Context.MODE_PRIVATE)
        sp.getStringSet("ids", emptySet())!!.forEach { am.cancel(pi(c, it.toInt(), "")) }
        sp.edit().remove("ids").apply()
    }
}
