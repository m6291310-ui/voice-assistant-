package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings

object AppOpener {
    // أسماء عربي -> جزء من اسم التطبيق بالإنجليزي
    private val ALIAS = mapOf(
        "فيسبوك" to "facebook", "فيس" to "facebook", "واتساب" to "whatsapp", "واتس" to "whatsapp",
        "يوتيوب" to "youtube", "انستجرام" to "instagram", "انستغرام" to "instagram", "تيكتوك" to "tiktok",
        "ماسنجر" to "messenger", "تليجرام" to "telegram", "تلجرام" to "telegram", "تويتر" to "twitter",
        "سنابشات" to "snapchat", "جيميل" to "gmail", "كروم" to "chrome", "خرائط" to "maps",
        "كاميرا" to "camera", "اعدادات" to "settings", "ساعه" to "clock", "حاسبه" to "calc", "هاتف" to "dialer"
    )

    @Suppress("DEPRECATION")
    fun open(ctx: Context, query: String): String {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = Parser.mp(query).trim().replace(" ", "").removePrefix("ال")
        val alias = ALIAS[q]
        fun lbl(r: android.content.pm.ResolveInfo) = Parser.mp(r.loadLabel(pm).toString()).replace(" ", "")
        val hit = (if (alias != null) list.firstOrNull { lbl(it).contains(alias) }
            ?: list.firstOrNull { it.activityInfo.packageName.lowercase().contains(alias) } else null)
            ?: list.firstOrNull { val l = lbl(it).removePrefix("ال"); l.length > 1 && q.length > 1 && (l == q || l.contains(q) || q.contains(l)) }
            ?: return "مش لاقي تطبيق اسمه $query"
        val label = hit.loadLabel(pm).toString()
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "مقدرتش افتح $label"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(ctx)) {
            try { ctx.startActivity(intent); return "بفتح $label" } catch (e: Exception) { }
        }
        // لو مفيش صلاحية: إشعار تدوس عليه (أو بيظهر لوحده على الشاشة المقفولة)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("open", "فتح التطبيقات", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 77, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, "open")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("افتح $label")
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .build()
        nm.notify(77, n)
        return "دوس على الإشعار عشان تفتح $label"
    }
}
