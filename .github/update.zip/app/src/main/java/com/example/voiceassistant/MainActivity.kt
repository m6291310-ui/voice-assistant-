package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var info: TextView
    private lateinit var permBtn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        btn = Button(this).apply { textSize = 20f; setOnClickListener { toggle() } }
        permBtn = Button(this).apply {
            text = "السماح بفتح التطبيقات (مرة واحدة)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))) }
        }
        info = TextView(this).apply { textSize = 16f; setPadding(0, 32, 0, 0) }
        root.addView(btn)
        root.addView(permBtn)
        root.addView(ScrollView(this).apply { addView(info) })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java)); refresh(); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(need.toTypedArray(), 1)
        } else start()
    }

    private fun start() { startForegroundService(Intent(this, VoiceService::class.java)); btn.postDelayed({ refresh() }, 400) }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
    }

    private fun refresh() {
        btn.text = if (VoiceService.running) "⏹ إيقاف الاستماع" else "🎙️ ابدأ الاستماع"
        permBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        val s = Store(this)
        val sb = StringBuilder()
        sb.append("قول «مساعد» وبعدها الأمر، مثلا:\n")
        sb.append("• مساعد، تايمر خمس دقايق\n• مساعد، ضيف مهمة اتصل بماما\n• مساعد، ضيف لبن وعيش لقايمة المشتريات\n• مساعد، اقرا المهام\n• مساعد، افتح فيسبوك\n\n")
        sb.append("✅ المهام:\n")
        if (s.tasks.isEmpty()) sb.append("  (فاضية)\n")
        s.tasks.forEach { sb.append(if (it.done) "  ☑ " else "  ☐ ").append(it.text).append("\n") }
        s.lists.forEach { (k, v) ->
            sb.append("\n🛒 ").append(k).append(":\n")
            v.forEach { sb.append(if (it.done) "  ☑ " else "  ☐ ").append(it.text).append("\n") }
        }
        info.text = sb.toString()
    }
}
