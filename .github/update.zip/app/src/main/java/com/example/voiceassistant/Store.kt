package com.example.voiceassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Item(var text: String, var done: Boolean)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("va", Context.MODE_PRIVATE)
    val tasks = mutableListOf<Item>()
    val lists = linkedMapOf<String, MutableList<Item>>()

    init {
        try {
            val o = JSONObject(sp.getString("d", "{}") ?: "{}")
            fun arr(a: JSONArray) = MutableList(a.length()) {
                val x = a.getJSONObject(it); Item(x.getString("t"), x.getBoolean("d"))
            }
            o.optJSONArray("tasks")?.let { tasks.addAll(arr(it)) }
            o.optJSONObject("lists")?.let { l -> l.keys().forEach { k -> lists[k] = arr(l.getJSONArray(k)) } }
        } catch (e: Exception) { }
    }

    fun save() {
        fun js(a: List<Item>) = JSONArray().also { r -> a.forEach { r.put(JSONObject().put("t", it.text).put("d", it.done)) } }
        val l = JSONObject()
        lists.forEach { (k, v) -> l.put(k, js(v)) }
        val o = JSONObject().put("tasks", js(tasks)).put("lists", l)
        sp.edit().putString("d", o.toString()).apply()
    }
}
