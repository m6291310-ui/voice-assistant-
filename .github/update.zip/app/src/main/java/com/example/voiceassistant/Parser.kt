package com.example.voiceassistant

import kotlin.math.roundToLong

object Parser {
    private val NW = mapOf(
        "واحد" to 1.0, "واحده" to 1.0, "اتنين" to 2.0, "اثنين" to 2.0, "تلاته" to 3.0, "ثلاثه" to 3.0, "تلات" to 3.0,
        "اربعه" to 4.0, "اربع" to 4.0, "خمسه" to 5.0, "خمس" to 5.0, "سته" to 6.0, "ست" to 6.0, "سبعه" to 7.0, "سبع" to 7.0,
        "تمانيه" to 8.0, "ثمانيه" to 8.0, "تمن" to 8.0, "تسعه" to 9.0, "تسع" to 9.0, "عشره" to 10.0, "عشر" to 10.0,
        "احداشر" to 11.0, "اتناشر" to 12.0, "تلاتاشر" to 13.0, "اربعتاشر" to 14.0, "خمستاشر" to 15.0,
        "عشرين" to 20.0, "تلاتين" to 30.0, "ثلاثين" to 30.0, "اربعين" to 40.0, "خمسين" to 50.0, "ستين" to 60.0
    )

    // تطبيع حرف بحرف (نفس الطول) عشان نقدر نرجع النص الأصلي بعد المطابقة
    fun mp(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    'أ', 'إ', 'آ' -> 'ا'
                    'ة' -> 'ه'
                    'ى' -> 'ي'
                    'ئ' -> 'ي'
                    'ؤ' -> 'و'
                    else -> ch.lowercaseChar()
                }
            )
        }
        return sb.toString()
    }

    private fun strip(s: String) = mp(s).removePrefix("ال")

    fun words(sec: Long): String {
        val h = sec / 3600; val m = sec % 3600 / 60; val x = sec % 60
        val p = mutableListOf<String>()
        if (h > 0) p += "$h ساعة"
        if (m > 0) p += "$m دقيقة"
        if (x > 0) p += "$x ثانية"
        return p.joinToString(" و ")
    }

    fun parseDur(t0: String): Long {
        var t = t0; var sec = 0.0; var f = false
        fun sub(re: String, v: Double) {
            val r = Regex(re)
            if (r.containsMatchIn(t)) { sec += v; f = true; t = r.replaceFirst(t, " ") }
        }
        sub("""ساعه\s*و\s*نص""", 5400.0)
        sub("""(?:نص|نصف)\s+ساعه""", 1800.0)
        sub("""ربع\s+ساعه""", 900.0)
        sub("""(?:تلت|ثلث)\s+ساعه""", 1200.0)
        sub("""(?:نص|نصف)\s+دقيقه""", 30.0)
        val re = Regex("""(\d+(?:[.,]\d+)?|\S+)?\s*(ساعتين|دقيقتين|ثانيتين|ساعات|ساعه|دقايق|دقيقه|ثواني|ثوان|ثانيه)""")
        for (m in re.findAll(t)) {
            val u = m.groupValues[2]
            var w = m.groupValues[1]
            var n = 1.0
            if (u.endsWith("تين")) n = 2.0
            else if (w.isNotEmpty() && w[0].isDigit()) n = w.replace(',', '.').toDoubleOrNull() ?: 1.0
            else {
                if (w !in NW && w.startsWith("و")) w = w.substring(1)
                NW[w]?.let { n = it }
            }
            sec += n * (if (u.startsWith("ساع")) 3600 else if (u.startsWith("د")) 60 else 1)
            f = true
        }
        return if (f) sec.roundToLong() else 0L
    }

    private fun findIn(a: List<Item>, q: String): Item? {
        val n = mp(q)
        return a.firstOrNull { !it.done && (mp(it.text).contains(n) || n.contains(mp(it.text))) }
            ?: a.firstOrNull { mp(it.text).contains(n) }
    }

    private fun getList(s: Store, name: String): String {
        val k = s.lists.keys.firstOrNull { strip(it) == strip(name) }
        if (k != null) return k
        s.lists[name] = mutableListOf()
        return name
    }

    private val R_ADD_LIST = Regex("""^(?:ضيف|اضف|اضافه|زود|حط)\s+(.+?)\s+(?:(?:الي|في|علي)\s+)?(?:لل|ال|ل)?قايمه(?:\s+(.+))?$""")
    private val R_DEL_ITEM = Regex("""^(?:امسح|احذف|شيل)\s+(.+?)\s+من\s+(?:لل|ال|ل)?قايمه(?:\s+(.+))?$""")
    private val R_CLEAR_LIST = Regex("""^(?:امسح|احذف|فضي)\s+(?:ال)?قايمه\s+(.+)$""")
    private val R_SHOW_LIST = Regex("""^(?:اعرض|وريني|افتح|اقرا|قولي)\s+(?:ال)?قايمه\s+(.+)$""")
    private val R_SHOW_TASKS = Regex("""^(?:اعرض|وريني|اقرا|قولي)\s+(?:ال)?مهام""")
    private val R_CLEAR_TASKS = Regex("""^(?:امسح|احذف|شيل)\s+(?:كل\s+)?(?:ال)?مهام|^امسح الكل""")
    private val R_DEL_TASK = Regex("""^(?:امسح|احذف|شيل)\s+مهمه\s+(.+)$""")
    private val R_ADD_TASK = Regex("""^(?:(?:ضيف|اضف|اضافه|سجل|زود)\s+)?مهمه(?:\s+جديده)?\s+(.+)$""")
    private val R_DONE = Regex("""^(?:خلصت|خلصنا|انجزت|كملت|تم)\s+(?:مهمه\s+)?(.+)$""")
    private val R_CANCEL = Regex("""(?:الغي|الغ|وقف|اوقف|امسح|شيل|اقفل)\s+(?:ال)?(?:تايمر|موقت|عداد|منبه)""")
    private val R_TIMER = Regex("""(?:تايمر|موقت|عداد|منبه|فكرني)""")
    private val R_OPEN = Regex("""^(?:افتح|افتحلي|فتح|اوبن)\s+(?:تطبيق\s+)?(.+)$""")

    /** يرجع الرد المنطوق، أو null لو الأمر مش مفهوم */
    fun handle(raw: String, s: Store, timer: (Long) -> Unit, cancelTimers: () -> Unit, open: (String) -> String): String? {
        val c = raw.replace(Regex("[\u064B-\u0652\u0640]"), "").replace(Regex("\\s+"), " ").trim()
        val t = mp(c)
        if (t.isEmpty()) return null
        fun g(m: MatchResult, i: Int) = m.groups[i]?.let { c.substring(it.range) }?.trim() ?: ""
        var m: MatchResult?

        m = R_ADD_LIST.find(t)
        if (m != null) {
            val items = g(m, 1).split(Regex("""\s+و\s+|[،,]\s*""")).map { it.trim() }.filter { it.isNotEmpty() }
            val name = getList(s, g(m, 2).ifEmpty { "عامة" })
            items.forEach { s.lists[name]!!.add(Item(it, false)) }
            s.save()
            return "ضفت " + items.joinToString(" و ") + " لقايمة " + name
        }
        m = R_DEL_ITEM.find(t)
        if (m != null) {
            val name = getList(s, g(m, 2).ifEmpty { "عامة" })
            val it = findIn(s.lists[name]!!, g(m, 1)) ?: return "ملقتش " + g(m, 1) + " في " + name
            s.lists[name]!!.remove(it); s.save()
            return "شلت " + it.text + " من " + name
        }
        m = R_CLEAR_LIST.find(t)
        if (m != null) { val name = getList(s, g(m, 1)); s.lists.remove(name); s.save(); return "مسحت قايمة $name" }
        m = R_SHOW_LIST.find(t)
        if (m != null) {
            val name = getList(s, g(m, 1))
            val a = s.lists[name]!!.filter { !it.done }.map { it.text }
            return if (a.isEmpty()) "$name فاضية" else "في $name: " + a.joinToString("، ")
        }
        if (R_SHOW_TASKS.containsMatchIn(t)) {
            val a = s.tasks.filter { !it.done }.map { it.text }
            return if (a.isEmpty()) "مفيش مهام متبقية" else "عندك: " + a.joinToString("، ")
        }
        if (R_CLEAR_TASKS.containsMatchIn(t)) { s.tasks.clear(); s.save(); return "مسحت كل المهام" }
        m = R_DEL_TASK.find(t)
        if (m != null) {
            val it = findIn(s.tasks, g(m, 1)) ?: return "ملقتش المهمة دي"
            s.tasks.remove(it); s.save(); return "مسحت مهمة " + it.text
        }
        m = R_ADD_TASK.find(t)
        if (m != null) { s.tasks.add(Item(g(m, 1), false)); s.save(); return "ضفت المهمة: " + g(m, 1) }
        m = R_DONE.find(t)
        if (m != null) {
            val q = g(m, 1)
            var it = findIn(s.tasks, q)
            if (it == null) for (l in s.lists.values) { it = findIn(l, q); if (it != null) break }
            if (it == null) return "ملقتش $q"
            it.done = true; s.save(); return "تمام، خلصت " + it.text
        }
        if (R_CANCEL.containsMatchIn(t)) { cancelTimers(); return "الغيت التايمرات" }
        if (R_TIMER.containsMatchIn(t)) {
            val sec = parseDur(t)
            if (sec <= 0) return "قولي المدة، مثلا تايمر خمس دقايق"
            timer(sec)
            return "شغلت تايمر " + words(sec)
        }
        m = R_OPEN.find(t)
        if (m != null) return open(g(m, 1))
        return null
    }
}
