package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** خدمة بتسمع في الخلفية (والشاشة مقفولة) وتنفذ الأوامر اللي بتبدأ بكلمة "مساعد". */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile var running = false
        // غيّرها لـ false لو عايز الأوامر تشتغل من غير ما تقول "مساعد" الأول
        const val REQUIRE_WAKE_WORD = true
        private val WAKE = Regex("""^\s*(?:يا\s+)?(?:ال)?مساعد(?:ي)?[\s،,]*""")
    }

    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private lateinit var store: Store

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("ar", "EG")
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { h.post { listen() } }
            @Deprecated("deprecated") override fun onError(u: String?) { h.post { listen() } }
        })
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        startFg()
        if (!running) { running = true; h.post { listen() } }
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("svc", "الاستماع", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("المساعد بيسمعك")
            .setContentText("قول «مساعد» وبعدها الأمر")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
            sr?.cancel()
            h.postDelayed({ listen() }, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 600)
        }
        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            process(text)
        }
    }

    private fun listen() {
        if (!running) return
        if (sr == null) sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { sr?.startListening(i) } catch (e: Exception) { h.postDelayed({ listen() }, 2000) }
    }

    private fun process(text: String?) {
        var reply: String? = null
        if (text != null) {
            val norm = Parser.mp(text)
            val m = WAKE.find(norm)
            if (m != null || !REQUIRE_WAKE_WORD) {
                val cmd = if (m != null) text.substring(minOf(m.range.last + 1, text.length)) else text
                reply = Parser.handle(cmd, store, { sec -> Timers.set(this, sec) }, { Timers.cancelAll(this) })
                    ?: if (cmd.isBlank()) "أيوه؟" else "مفهمتش"
            }
        }
        if (reply != null && tts != null) tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "u")
        else h.postDelayed({ listen() }, 300)
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); sr = null
        tts?.shutdown()
        super.onDestroy()
    }
}
